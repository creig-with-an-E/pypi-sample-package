# Purpose of project

Taking a go at pypi packaging